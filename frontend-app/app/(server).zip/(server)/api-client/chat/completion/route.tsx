export async function POST(request: Request) {
  return new Response("POST /chat/completion");
}
