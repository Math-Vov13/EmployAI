export async function GET() {
  return new Response("GET /chat/history");
}
