export async function POST(request: Request) {
  return new Response("POST /auth/token");
}
