export function GET() {
  return new Response("API Client Route");
}
