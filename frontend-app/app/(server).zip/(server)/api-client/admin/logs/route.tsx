export async function GET() {
  return new Response("GET /admin/logs");
}
