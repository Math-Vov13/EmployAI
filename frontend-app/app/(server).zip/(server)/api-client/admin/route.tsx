export async function POST(request: Request) {
  return new Response("POST /admin (token)");
}
